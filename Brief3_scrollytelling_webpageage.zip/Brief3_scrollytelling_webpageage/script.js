// this creates variable and allows us to select the html elements (in our case ummm the container and the posts)
const container = document.querySelector(".container2");
const posts = document.querySelectorAll(".post");

//this sets the starting active post to the first post
let currentIndex = 0;

//Create the main /horizontal scroll bit function
       function goToPost(index) {
        // this is the function that will be called when we click on the page, it takes an index as an argument which will be the post we want to go to

        //MAKING SURE THE CAROUSEL STAYS WITHIN THE BOUNDS OF THE POSTS
            // Stop the carousel beginning before the first post
            if (index < 0) {
              index = 0;
            }
            // stops the carousel going past the last post
            if (index > posts.length - 1) {
              index = posts.length - 1;
            }
            // declare current index to current post
            currentIndex = index;


        //CHANGING CLASS NAMES TO CHANGE STYLES
            // remove active from every post
          posts.forEach((post) => {
            post.classList.remove("active");
          });

          // add active to the current post (remember this changes how it gets styled)
          posts[currentIndex].classList.add("active");

        
        //POSITIONING THE ACTIVE POST IN THE CENTRE
          // select the current post
          const post = posts[currentIndex];
          // work out the center of the post 
          const postCenter = post.offsetLeft + post.offsetWidth / 2;
          // work out the center of the screen
          const screenCenter = window.innerWidth / 2;

          // work out how far the row needs to move
          const moveAmount = screenCenter - postCenter;

          //aanimate the row so the active post moves to the centre
          gsap.to(container, {
            x: moveAmount,
            duration: 0.8,
            ease: "power2.out"
          });
      }

// click on the page to go left or right
document.addEventListener("click", (event) => {
  const clickX = event.clientX;
  const screenWidth = window.innerWidth;

  if (clickX < screenWidth / 3) {
    goToPost(currentIndex - 1);
  }

  if (clickX > screenWidth * 2 / 3) {
    goToPost(currentIndex + 1);
  }
});



// start with the first post active
goToPost(0);