const rightComments = document.querySelector(".right-comments");
const commentOne = document.querySelector(".comment-one");
const commentTwo = document.querySelector(".comment-two");
const commentThree = document.querySelector(".comment-three");

const container = document.querySelector(".container2");
const posts = document.querySelectorAll(".post");

const leftWing = document.querySelector(".wing-left");
const rightWing = document.querySelector(".wing-right");

const leftAccountName = document.querySelector(".left-account-name");
const leftDate = document.querySelector(".left-date");
const leftMainText = document.querySelector(".left-main-text");
const leftHashtags = document.querySelector(".left-hashtags");

const rightStats = document.querySelector(".right-stats");

const likeValue = document.querySelector(".like-value");
const commentValue = document.querySelector(".comment-value");
const shareValue = document.querySelector(".share-value");

const tooltip = document.querySelector(".analysis-tooltip");
const hotspotContainer = document.querySelector(".image-hotspots");

let currentIndex = 0;

const postStats = [
    //post 1
  { likes: 23, comments: 23, shares: 23 },
    //post 2
  { likes: 45, comments: 12, shares: 8 },
    //post 3
  { likes: 67, comments: 31, shares: 19 },
    //post 4
  { likes: 102, comments: 54, shares: 33 },
    //post 5
  { likes: 88, comments: 40, shares: 27 },
    //post 6
  { likes: 34, comments: 9, shares: 11 },
    //post 7
  { likes: 102, comments: 54, shares: 33 },
    //post 8
  { likes: 88, comments: 40, shares: 27 },
    //post 9
  { likes: 34, comments: 9, shares: 11 }
    
];

const postComments = [
  //post 1
  [
    "Finally someone is saying what everyone is thinking.",
    "This is exactly why people are worried about the country changing.",
    "Protect women and children first. No more excuses."
  ],
  //post 2
  [
    "Britain has always been a Christian country.",
    "Why is this even controversial to say?",
    "The yes or no question makes it feel like common sense."
  ],
  //post 3
  [
    "This is happening on every high street now.",
    "They make it look ordinary so people stop questioning it.",
    "The shopfront makes the issue feel close to home."
  ],
  //post 4
  [
    "Other countries have rules, so why can’t we?",
    "Public prayer should not take over the streets.",
    "The question pushes people towards agreeing with a ban."
  ],
  //post 5
  [
    "This is about women’s safety, not hate.",
    "The image uses protection language to justify restriction.",
    "It turns clothing into a national debate."
  ],
  //post 6
  [
    "Should halal meat be labelled everywhere?",
    "This makes food look like a political threat.",
    "The yes or no format makes the issue feel simple."
  ]
];

const postText = [
    //post 1
  {
    account: "Raise the colours",
    date: "Date",
    text: `Raise the Colours stands with Shrewsbury.<br>
      Ryan and the team attended 
      <span class="annotation-word" data-note="This makes the post feel grounded in a real local place, rather than just an abstract political claim.">Raise the Flags Shrewsbury Plus’ event</span> 
      on Saturday to show their support. 
      <span class="annotation-word" data-note="This phrase turns the post into a movement slogan, making the account sound determined and organised.">We will not stop.</span> 
      <span class="annotation-word" data-note="This uses the language of protection to frame the issue as one of safety, rather than exclusion.">Women and Children deserve to feel safe</span> 
      in their own country.`,
    hashtags: "#raisethecoloursofficial #RaiseTheColours #WeWillNotStop #shrewsburypatriots"
  },
    //post 2
  {
    account: "Raise the colours",
    date: "Date",
    text: `Britain is and should remain a Christian country. 
      This post turns 
      <span class="annotation-word" data-note="This uses national identity as something fixed and threatened, making belonging feel conditional.">national identity</span> 
      into a yes or no question, using faith and flags to make exclusion feel like public debate.`,
    hashtags: "#britain #christiancountry #nationalidentity"
  },
    //post 3
  {
    account: "Raise the colours",
    date: "Date",
    text: `The 
      <span class="annotation-word" data-note="The shopfront makes the political claim feel local and ordinary, as though the issue is happening on a familiar high street.">halal shopfront</span> 
      is staged as an ordinary British street scene, making the issue feel local, immediate and familiar. 
      The image turns everyday visibility into a political threat.`,
    hashtags: "#halalmeat #britishstreets #localdebate"
  },
    //post 4
  {
    account: "Raise the colours",
    date: "Date",
    text: `This post uses a dramatic policy comparison to make an anti-Muslim restriction feel reasonable. 
      The 
      <span class="annotation-word" data-note="The question format invites the audience to participate, while narrowing the answer into agreement or disagreement with a ban.">question format</span> 
      invites the audience to answer with support for bans.`,
    hashtags: "#publicprayer #debate #ukpolitics"
  },
    //post 5
  {
    account: "Raise the colours",
    date: "Date",
    text: `The image uses the language of women’s safety to frame Muslim dress as a national problem. 
      It borrows the style of a 
      <span class="annotation-word" data-note="Campaign-style design makes the image feel urgent, organised and public-facing, even if the post is artificially staged.">campaign poster</span> 
      to make the message feel urgent.`,
    hashtags: "#ban #womenssafety #ukdebate"
  },
    //post 6
  {
    account: "Raise the colours",
    date: "Date",
    text: `This post uses a shopfront to make halal meat feel like a visible symbol of cultural change. 
      The design turns a food practice into something to vote on.`,
    hashtags: "#halal #meat #yesorno"
  }
];

const postHotspots = [
    // Post 1
  [
    {
      x: 0.08,
      y: 0.05,
      w: 0.22,
      h: 0.35,
      note: "The Union Jack works as a shortcut for national identity and belonging."
    },
    {
      x: 0.18,
      y: 0.62,
      w: 0.65,
      h: 0.22,
      note: "The hand-written sign makes the AI image feel like a protest photograph, even though it is staged."
    }
  ],
  //post 2
  [
    {
      x: 0.1,
      y: 0.6,
      w: 0.75,
      h: 0.25,
      note: "The yes/no structure turns a complex political issue into a simple reaction prompt."
    }
  ],
  //post 3
  [
    {
      x: 0.1,
      y: 0.05,
      w: 0.8,
      h: 0.35,
      note: "The high street setting makes the post feel local, familiar and close to everyday life."
    }
  ],
  //post 4
  [
    {
      x: 0.08,
      y: 0.1,
      w: 0.85,
      h: 0.35,
      note: "Large block text dominates the image, so the viewer reads the claim before questioning the picture."
    }
  ],
  //post 5
  [
    {
      x: 0.12,
      y: 0.55,
      w: 0.75,
      h: 0.3,
      note: "The slogan turns clothing into a debate object, inviting judgement through a simple ban/no-ban frame."
    }
  ],
  //post 6    
  [
    {
      x: 0.08,
      y: 0.08,
      w: 0.82,
      h: 0.45,
      note: "The shopfront is used as evidence, making a cultural practice look like a visible public issue."
    }
  ]
];

function updateComments() {
  const comments = postComments[currentIndex];

  if (!comments) {
    return;
  }

  commentOne.textContent = comments[0];
  commentTwo.textContent = comments[1];
  commentThree.textContent = comments[2];
}

function updateLeftText() {
  const content = postText[currentIndex];

  if (!content) {
    return;
  }

  leftAccountName.textContent = content.account;
  leftDate.textContent = content.date;
  leftMainText.innerHTML = content.text;
  leftHashtags.textContent = content.hashtags;
}

function updateStats() {
  const stats = postStats[currentIndex];

  if (!stats) {
    return;
  }

  likeValue.textContent = stats.likes;
  commentValue.textContent = stats.comments;
  shareValue.textContent = stats.shares;
}

function animateStats() {
  const stats = postStats[currentIndex];

  if (!stats) {
    return;
  }

  const counter = {
    likes: 0,
    comments: 0,
    shares: 0
  };

  gsap.to(counter, {
    likes: stats.likes,
    comments: stats.comments,
    shares: stats.shares,
    duration: 0.8,
    ease: "power2.out",
    onUpdate: () => {
      likeValue.textContent = Math.round(counter.likes);
      commentValue.textContent = Math.round(counter.comments);
      shareValue.textContent = Math.round(counter.shares);
    }
  });
}

function showWings() {
  matchWingsToActiveImage();
  updateLeftText();
  updateComments();

  gsap.to(leftWing, {
    x: 605,
    opacity: 1,
    duration: 0.35,
    ease: "power2.out"
  });

  gsap.to(rightWing, {
    x: -581,
    opacity: 0.9,
    duration: 0.35,
    ease: "power2.out"
  });

  likeValue.textContent = "0";
  commentValue.textContent = "0";
  shareValue.textContent = "0";

  gsap.to(rightStats, {
    opacity: 1,
    duration: 0.35,
    ease: "power2.out",
    delay: 0.5,
    onStart: animateStats
  });

  gsap.to(rightComments, {
  opacity: 1,
  duration: 0.35,
  ease: "power2.out",
  delay: 0.7
});
}

function hideWings(onCompleteFunction) {
  gsap.to(leftWing, {
    x: 0,
    opacity: 0,
    duration: 0.25,
    ease: "power2.in"
  });

  gsap.to(rightWing, {
    x: 0,
    opacity: 0,
    duration: 0.25,
    ease: "power2.in"
  });

  gsap.to(rightStats, {
    opacity: 0,
    duration: 0.05,
    ease: "power2.in",
    onComplete: onCompleteFunction
  });

  if (hotspotContainer) {
    hotspotContainer.innerHTML = "";
  }

  gsap.to(rightComments, {
  opacity: 0,
  duration: 0.2,
  ease: "power2.in"
});
}

function matchWingsToActiveImage() {
  const activeImage = document.querySelector(".post.active img");

  if (!activeImage) {
    return;
  }

  const box = activeImage.getBoundingClientRect();
  const wingOffset = 1;

  leftWing.style.top = box.top - 1 + "px";
  rightWing.style.top = box.top + wingOffset + "px";

  rightWing.style.height = box.height + "px";
  rightWing.style.width = "auto";

  leftWing.style.width = "400px";
  leftWing.style.height = "595px";

  rightStats.style.top = "250px";
  rightComments.style.top = "310px";
}

function updateHotspots() {
  if (!hotspotContainer) {
    return;
  }

  hotspotContainer.innerHTML = "";

  const activeImage = document.querySelector(".post.active img");

  if (!activeImage) {
    return;
  }

  const imageBox = activeImage.getBoundingClientRect();
  const hotspots = postHotspots[currentIndex] || [];

  hotspots.forEach((spot) => {
    const hotspot = document.createElement("div");

    hotspot.classList.add("hotspot");
    hotspot.dataset.note = spot.note;

    hotspot.style.left = imageBox.left + imageBox.width * spot.x + "px";
    hotspot.style.top = imageBox.top + imageBox.height * spot.y + "px";
    hotspot.style.width = imageBox.width * spot.w + "px";
    hotspot.style.height = imageBox.height * spot.h + "px";

    hotspotContainer.appendChild(hotspot);
  });
}

function goToPost(index) {
  if (index < 0) {
    index = 0;
  }

  if (index > posts.length - 1) {
    index = posts.length - 1;
  }

  hideWings(() => {
    currentIndex = index;

    posts.forEach((post) => {
      post.classList.remove("active");
    });

    const activePost = posts[currentIndex];

    if (!activePost) {
      return;
    }

    activePost.classList.add("active");
    updateLeftText();

    const postCenter = activePost.offsetLeft + activePost.offsetWidth / 2;
    const screenCenter = window.innerWidth / 2;
    const targetX = screenCenter - postCenter;

    gsap.killTweensOf(container);

    gsap.to(container, {
      x: targetX,
      duration: 0.7,
      ease: "power2.out",
      onUpdate: () => {
        matchWingsToActiveImage();
        updateHotspots();
      },
      onComplete: () => {
        matchWingsToActiveImage();
        updateHotspots();
        showWings();
      }
    });
  });
}

document.addEventListener("click", (event) => {
  const clickX = event.clientX;
  const screenWidth = window.innerWidth;

  if (clickX < screenWidth / 3) {
    goToPost(currentIndex - 1);
  }

  if (clickX > screenWidth * 2 / 3) {
    goToPost(currentIndex + 1);
  }
});

window.addEventListener("resize", () => {
  goToPost(currentIndex);
});

document.addEventListener("mouseover", (event) => {
  const target = event.target.closest("[data-note]");

  if (!target || !tooltip) {
    return;
  }

  tooltip.textContent = target.dataset.note;
  tooltip.style.opacity = 1;
});

document.addEventListener("mousemove", (event) => {
  if (!tooltip) {
    return;
  }

  tooltip.style.left = event.clientX + "px";
  tooltip.style.top = event.clientY + "px";
});

document.addEventListener("mouseout", (event) => {
  const target = event.target.closest("[data-note]");

  if (!target || !tooltip) {
    return;
  }

  tooltip.style.opacity = 0;
});

goToPost(0);